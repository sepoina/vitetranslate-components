// export * from './components/Rating'
import { TranslateContext, TranslateContainer } from "./components/TranslateContainer.jsx";
import Translate from "./components/Translate.jsx";

export {
  TranslateContainer,
};