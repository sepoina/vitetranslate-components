declare module '@sepoina/vitetranslate-components';
